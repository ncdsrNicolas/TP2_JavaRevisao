package br.edu.fatecpg.treinamentotecnologico.view;
import br.edu.fatecpg.treinamentotecnologico.*;
import br.edu.fatecpg.treinamentotecnologico.model.Aluno;
import br.edu.fatecpg.treinamentotecnologico.model.TreinamentoOnline;
import br.edu.fatecpg.treinamentotecnologico.model.TreinamentoPresencial;

public class Main {

	public static void main(String[] args) {
		Aluno a1 = new Aluno("Nicolas", 8.5);
		Aluno a2 = new Aluno("Tiago", 5.6);

        TreinamentoPresencial presencial = new TreinamentoPresencial(1, "Carlos", "Java", "Sala 101");
        presencial.definirCargaHoraria(40);
        presencial.adicionarAluno(a1);
        presencial.adicionarAluno(a2);
 
        TreinamentoOnline online = new TreinamentoOnline(2, "Ana", "Python", "https://link-treinamento.com");
        online.definirCargaHoraria(60);
        online.adicionarAluno(a1);
 
        System.out.println("Disponibilidade do instrutor (presencial): " + presencial.verificarDisponibilidade());
        System.out.println("Média dos alunos (presencial): " + presencial.calcularMediaAlunos());
	}

}
