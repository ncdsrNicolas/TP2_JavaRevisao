package br.edu.fatecpg.treinamentotecnologico.controler;
import java.util.List;
import java.util.ArrayList;

import br.edu.fatecpg.treinamentotecnologico.model.*;

public class TreinamentoController {
	private ArrayList<Aluno> alunos = new ArrayList<>();
}
