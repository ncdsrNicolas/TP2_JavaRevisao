package br.edu.fatecpg.treinamentotecnologico.model;

public class TreinamentoPresencial extends Treinamento{
	private String local;
	
	public TreinamentoPresencial(int id, String nomeInstrutor, String linguagemEnsinada, String local) {
		super(id, nomeInstrutor, linguagemEnsinada);
		this.local = local;
	}
	
	public String getLocal() {
		return local;
	}
}
