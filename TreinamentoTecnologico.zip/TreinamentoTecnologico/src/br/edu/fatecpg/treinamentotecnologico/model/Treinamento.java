package br.edu.fatecpg.treinamentotecnologico.model;
import java.util.List;
import java.util.ArrayList;
import br.edu.fatecpg.treinamentotecnologico.controler.*;

public class Treinamento {
	protected int id;
    protected String nomeInstrutor;
    protected String linguagemEnsinada;
    protected ArrayList<Aluno> alunos;
    protected int cargaHoraria;
 
    public Treinamento(int id, String nomeInstrutor, String linguagemEnsinada) {
this.id = id;
        this.nomeInstrutor = nomeInstrutor;
        this.linguagemEnsinada = linguagemEnsinada;
        this.alunos = new ArrayList<>();
    }
 
    public boolean verificarDisponibilidade() {
        // Simulação — sempre retorna true
        return true;
    }
 
    public void definirCargaHoraria(int horas) {
        this.cargaHoraria = horas;
    }
 
    public boolean verificarUltimoTreinamento(Aluno aluno) {
        // Simulação: só verifica se cargaHoraria <= 80
        return this.cargaHoraria <= 80;
    }
 
    public double calcularMediaAlunos() {
        if (alunos.isEmpty()) return 0.0;
        double soma = 0;
        for (Aluno a : alunos) {
            soma += a.getNotaFinal();
        }
        return soma / alunos.size();
    }
 
    public void adicionarAluno(Aluno aluno) {
        alunos.add(aluno);
    }
	
}
