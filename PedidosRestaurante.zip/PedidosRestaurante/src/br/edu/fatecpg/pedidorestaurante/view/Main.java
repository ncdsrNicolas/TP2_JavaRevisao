package br.edu.fatecpg.pedidorestaurante.view;
import java.util.ArrayList;
import br.edu.fatecpg.pedidorestaurante.controler.*;
import br.edu.fatecpg.pedidorestaurante.model.*;

public class Main {

	public static void main(String[] args) {
		// Instanciando pedidos 1
				Pedido p1 = new Pedido(1);
				ItemPedido item1 = new ItemPedido("Yorgute", 5, 50.0);
				p1.adicionarItem(item1);
				
				ItemPedido item2 = new ItemPedido("Strogonoff", 1, 70.0);
				p1.adicionarItem(item2);
				p1.removerItem(item1);
				System.out.println("");
				
				Pedido p2 = new Pedido(2);
				ItemPedido item4 = new ItemPedido("Bolo Salgado", 3, 7.50);
				ItemPedido item5 = new ItemPedido("Coxinha Doce", 3, 12.50);
				
				p2.adicionarItem(item4);
				p2.adicionarItem(item5);
				System.out.println("");
				
				ArrayList<ItemPedido> itensDoPedido1 = p1.getItensPedido();
				ArrayList<ItemPedido> itensDoPedido2 = p2.getItensPedido();
				
				System.out.println("Total: " + p1.calcularTotalPedido());
				System.out.println("");
				
				System.out.println("Total: " + p2.calcularTotalPedido());
				System.out.println("");
				
				Restaurante r = new Restaurante(10); 
				r.reservarMesa(2);
				r.reservarMesa(11);
				r.reservarMesa(2);
				r.adicionarPedidos(p1);
				r.adicionarPedidos(p2);
				System.out.println("");
				
				ArrayList<Pedido> listaPedidos = r.getPedidos();
	}

}
